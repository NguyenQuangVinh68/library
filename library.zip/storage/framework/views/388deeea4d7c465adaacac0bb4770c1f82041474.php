<?php $__env->startSection('main'); ?>
    <div class="banner text-white">
        <div class="d-flex align-items-center justify-content-center" style="height: 450px;">
            <div>
                <h1 id="title_search" class="mb-4">Tìm kiếm sách trong thư viện</h1>
                <div class=" ">
                    <?php if (isset($component)) { $__componentOriginal454967c969a3d17d371dc706013575486a6c4ef0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FormSearch::class, []); ?>
<?php $component->withName('form-search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal454967c969a3d17d371dc706013575486a6c4ef0)): ?>
<?php $component = $__componentOriginal454967c969a3d17d371dc706013575486a6c4ef0; ?>
<?php unset($__componentOriginal454967c969a3d17d371dc706013575486a6c4ef0); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <section>
        <div class="my-5 container">
            <h3 class="text-center ">7 đầu sách mới nhất</h3>
            <div class="slider my-5">
                <?php
                    use App\Models\Sach;
                    $saches = Sach::orderBy('id', 'DESC')
                        ->limit(10)
                        ->get();
                ?>
                <?php $__currentLoopData = $saches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card border-0">
                        <div class="card-body " style=" background-color: transparent !important;">
                            <a href="#">
                                <img class="w-100" src="<?php echo e(asset('assets/images/books/' . $sach->anhbia)); ?>"
                                    alt="">
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('slick'); ?>
    <script src="<?php echo e(asset('assets/js/slick-custom.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\library\resources\views/pages/client/index.blade.php ENDPATH**/ ?>