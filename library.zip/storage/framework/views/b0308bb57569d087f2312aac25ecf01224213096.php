
<?php $__env->startSection('main'); ?>
    <section>
        <div class="row my-5 ">
            <div class="col-md-6 mb-1">
                <a class="text-capitalize nav-link fs-4 fw-bold " href="<?php echo e(route('muon.online')); ?>">đăng kí mượn online</a>
            </div>
            <div class="col-md-6 mb-1">
                <form action="" class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="Tìm kiếm theo mã sinh viên" name="key">
                    <button class="btn btn-primary" type="submit"><i class="bi bi-search"></i></button>
                </form>
            </div>
        </div>
    </section>
    <?php echo $__env->yieldContent('content'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\library\resources\views/pages/admin/muon_online/layout.blade.php ENDPATH**/ ?>