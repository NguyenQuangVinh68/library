<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\xampp\htdocs\Laravel\library\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>