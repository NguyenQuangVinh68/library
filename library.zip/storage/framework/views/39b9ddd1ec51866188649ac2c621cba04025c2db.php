
<?php $__env->startSection('content'); ?>
    <section class="section">

        <?php if(session('message')): ?>
            <div class="alert alert-danger mt-5">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>

        <?php if(isset($message) && $message != null): ?>
            <div class="alert alert-success ">
                <p class="text-capitalize"><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>

        <div class="row my-5" id="table-head">
            <div class="col-12">
                <div class="table-responsive">
                    <?php if(isset($kq)): ?>
                        <h4 class="text-center mb-5">Sách đang mượn</h4>
                        <table class="table mb-0">
                            <thead class="thead-dark">
                                <tr>
                                    <th>Mã sinh viên</th>
                                    <th>Tên sinh viên</th>
                                    <th>Mã sách</th>
                                    <th>Nhan đề</th>
                                    <th>Ngày mượn</th>
                                    <th>Ngày trả</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $kq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $muon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="<?php echo e($muon->ngaytra == date('Y-m-d') ? 'bg-danger' : ''); ?>">
                                        <td><?php echo e($muon->ma_user); ?></td>
                                        <td class="text-capitalize"><?php echo e($muon->ten_user); ?></td>
                                        <td><?php echo e($muon->masach); ?></td>
                                        <td class="w-25"><?php echo e($muon->nhande); ?></td>
                                        <td><?php echo e($muon->ngaymuon); ?></td>
                                        <td><?php echo e($muon->ngaytra); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('giahan.index', $muon->id)); ?>"
                                                class="btn btn-outline-success">Gia
                                                hạn</a>
                                            <button type="button"
                                                class="btn <?php echo e($muon->ngaytra == date('Y-m-d') ? 'btn-outline-light' : 'btn-outline-primary'); ?> block"
                                                data-bs-toggle="modal"
                                                data-bs-target="#tra<?php echo e($muon->id); ?>">Trả</button>
                                            <button type="button"
                                                class="btn <?php echo e($muon->ngaytra == date('Y-m-d') ? 'btn-outline-secondary' : 'btn-outline-danger'); ?> block"
                                                data-bs-toggle="modal"
                                                data-bs-target="#mat<?php echo e($muon->id); ?>">Mất</button>
                                        </td>
                                    </tr>

                                    
                                    <div class="modal fade" id="tra<?php echo e($muon->id); ?>" data-bs-backdrop="static"
                                        aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable"
                                            role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalCenterTitle">
                                                        Trả sách
                                                    </h5>
                                                    <button type="button" class="close" data-bs-dismiss="modal"
                                                        aria-label="Close">X</button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="<?php echo e(route('tra.action')); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="mamuon" value="<?php echo e($muon->id); ?>">
                                                        <input type="hidden" name="masach" value="<?php echo e($muon->masach); ?>">
                                                        <input type="hidden" name="nhande" value="<?php echo e($muon->nhande); ?>">
                                                        <input type="hidden" name="ma_user" value="<?php echo e($muon->ma_user); ?>">
                                                        <input type="hidden" name="maadm" value="admin">
                                                        <input type="hidden" name="ngaytra" value="<?php echo e(date('Y-m-d')); ?>">
                                                        <h4 class="text-center"> <?php echo e($muon->nhande); ?></h4>
                                                        <p class="text-center">Bạn có trắc chắn muốn trả "SÁCH" này?</p>
                                                        <div class="d-flex gap-3 mt-5">
                                                            <button type="submit" class="btn btn-danger w-50">Ok,
                                                                trả</button>
                                                            <button class="btn btn-secondary w-50" type="button"
                                                                data-bs-dismiss="modal" aria-label="Close">Hủy</button>
                                                        </div>
                                                    </form>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    

                                    
                                    <div class="modal " id="mat<?php echo e($muon->id); ?>" data-bs-backdrop="static"
                                        aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable"
                                            role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalCenterTitle">
                                                        Mất sách
                                                    </h5>
                                                    <button type="button" class="close" data-bs-dismiss="modal"
                                                        aria-label="Close">X</button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="<?php echo e(route('mat')); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php
                                                            $tienphat = DB::table('saches')
                                                                ->select('gia')
                                                                ->where('id', $muon->masach)
                                                                ->limit(1)
                                                                ->get();
                                                        ?>
                                                        
                                                        <input type="hidden" name="masach" value="<?php echo e($muon->masach); ?>">
                                                        <input type="hidden" name="nhande" value="<?php echo e($muon->nhande); ?>">
                                                        <input type="hidden" name="ma_user" value="<?php echo e($muon->ma_user); ?>">
                                                        <input type="hidden" name="mamuon" value="<?php echo e($muon->id); ?>">
                                                        <input type="hidden" name="maadm" value="admin">
                                                        <input type="hidden" name="ngaybaomat"
                                                            value="<?php echo e(date('Y-m-d')); ?>">
                                                        <input type="hidden" name="tienphat"
                                                            value="<?php echo e($tienphat[0]->gia * 2); ?>">
                                                        

                                                        <h4 class="text-center"> <?php echo e($muon->nhande); ?></h4>
                                                        <p class="text-center">Bạn có trắc chắn "Sách" này đã mất</p>
                                                        <div class="d-flex gap-3 mt-5">
                                                            <button type="submit" class="btn btn-danger w-50">Ok,
                                                                mất</button>
                                                            <button class="btn btn-secondary w-50" type="button"
                                                                data-bs-dismiss="modal" aria-label="Close">Hủy</button>
                                                        </div>
                                                    </form>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.admin.muonsach.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\library\resources\views/pages/admin/trasach/index.blade.php ENDPATH**/ ?>