
<?php $__env->startSection('content'); ?>

    <?php if(session('message')): ?>
        <div class="alert alert-success mt-5">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
    <?php if(count($data) > 0): ?>
        <section class="section">
            <h3 class="my-5 text-center">Danh sách đã đăng kí mượn online</h3>
            <div class="row" id="table-head">
                <div class="col-12">
                    <div class="table-responsive">
                        <table class="table mb-0">
                            <thead class="thead-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>Mã người dùng</th>
                                    <th>Tên người dùng</th>
                                    <th>Mã sách</th>
                                    <th>Nhan đề</th>
                                    <th>Ngày đăng kí mượn</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $muon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($muon->id); ?></td>
                                        <td><?php echo e($muon->ma_user); ?></td>
                                        <td class="text-capitalize"><?php echo e($muon->ten_user); ?></td>
                                        <td><?php echo e($muon->masach); ?></td>
                                        <td class="text-capitalize"><?php echo e($muon->nhande); ?></td>
                                        <td class="text-capitalize"><?php echo e(date_format($muon->created_at, 'Y-m-d')); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('muon.online.xacnhan', ['id_dangki' => $muon->id])); ?>"
                                                type="button" class="btn btn-outline-primary block">Xác
                                                nhận cho mượn</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
        <?php if(isset($data)): ?>
            <?php echo e($data->links('inc.pagination')); ?>

        <?php endif; ?>
    <?php else: ?>
        <div class="my-5">
            <h3 class="alert-danger text-capitalize p-3 text-center">Không có dữ liệu</h3>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.admin.muon_online.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\library\resources\views/pages/admin/muon_online/index.blade.php ENDPATH**/ ?>