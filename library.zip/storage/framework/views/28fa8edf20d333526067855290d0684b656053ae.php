
<?php $__env->startSection('content'); ?>
    <?php if(session('message')): ?>
        <div class="alert alert-danger mt-5">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>

    <div class="w-50 mx-auto">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title text-center"><?php echo e(isset($khoa) ? 'Chỉnh sửa khoa' : 'Thêm khoa'); ?></h4>
            </div>
            <div class="card-content">
                <div class="card-body">
                    <form class="form form-vertical" autocomplete="off"
                        action="<?php echo e(isset($khoa) ? route('khoa.update', $khoa->id) : route('khoa.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($khoa)): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php else: ?>
                            <?php echo method_field('POST'); ?>
                        <?php endif; ?>
                        <div class="form-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group">
                                        <label>Tên khoa</label>
                                        <input type="text" class="form-control" name="tenkhoa" id="slug"
                                            onkeyup="ChangeToSlug()" placeholder="Nhập tên khoa"
                                            value="<?php echo e(isset($khoa) ? $khoa->tenkhoa : ''); ?>">
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                        <label>Slug</label>
                                        <input type="text" class="form-control" name="slug" id="convert_slug"
                                            placeholder="Nhập tên khoa" value="<?php echo e(isset($khoa) ? $khoa->slug : ''); ?>">
                                    </div>
                                </div>

                                <div class="col-12 d-flex justify-content-end">
                                    <button type="submit" class="btn btn-primary me-1 mb-1">
                                        <?php echo e(isset($khoa) ? 'Cập nhật' : 'Thêm'); ?>

                                    </button>
                                    <button type="reset" class="btn btn-light-secondary me-1 mb-1">
                                        Đặt lại
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.admin.khoa.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\library\resources\views/pages/admin/khoa/form.blade.php ENDPATH**/ ?>