
<?php $__env->startSection('content'); ?>
    <section class="section">

        <?php if(session('message')): ?>
            <div class="alert alert-danger mt-5">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success mt-5">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        

        <div class="container w-50 mx-auto">
            <div class="card">
                <div class="card-content">
                    <div class="card-header">
                        <h4 class="text-center">Mượn sách</h4>
                    </div>
                    <div class="card-body">
                        <form class="form form-vertical" action="<?php echo e(route('tim-sinhvien')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group">
                                        <label for="">Tìm sinh viên</label>
                                        <input class="form-control" type="text" name="ma_user" id="ma_user"
                                            placeholder="Tìm sinh viên theo mã số">
                                    </div>
                                </div>
                                <div class="col-12 d-flex justify-content-end">
                                    <button type="submit" class="btn btn-primary me-1 mb-1">
                                        Tìm
                                    </button>
                                    <button type="reset" class="btn btn-light-secondary me-1 mb-1">
                                        Đặt lại
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.admin.muonsach.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\library\resources\views/pages/admin/muonsach/index.blade.php ENDPATH**/ ?>