
<?php $__env->startSection('main'); ?>
    <?php if($saches->isNotEmpty()): ?>
        <div class="mt-5">
            <div class="container">
                <?php $__currentLoopData = $saches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginald94ef2ef116066c8ce49bf726279c794d329207a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Book\Books::class, ['sach' => $sach]); ?>
<?php $component->withName('book.books'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald94ef2ef116066c8ce49bf726279c794d329207a)): ?>
<?php $component = $__componentOriginald94ef2ef116066c8ce49bf726279c794d329207a; ?>
<?php unset($__componentOriginald94ef2ef116066c8ce49bf726279c794d329207a); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php if(method_exists($saches, 'links')): ?>
            <?php echo e($saches->links('inc.pagination')); ?>

        <?php endif; ?>
    <?php else: ?>
        <div class=" container my-5">
            <div class="alert-danger p-3">
                <h3 class="mb-0 text-center">Không có dữ liệu</h3>
            </div>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\library\resources\views/pages/client/sach.blade.php ENDPATH**/ ?>