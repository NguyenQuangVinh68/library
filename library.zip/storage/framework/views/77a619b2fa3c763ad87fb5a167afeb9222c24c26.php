<div class="container">
    <h3>Bình luận</h3>
    
    <form action="" method="POST">
        <?php echo method_field('POST'); ?>
        <div class="card">
            <div class="card-body">
                <div class="form-group mb-3">
                    <?php if(Auth::guard('web')->check()): ?>
                        <label for="exampleFormControlTextarea1" class="form-label"><span
                                class="text-capitalize"><?php echo e(Auth::guard('web')->user()->ten_user); ?></span> bình
                            luận:</label>
                    <?php else: ?>
                        <label for="exampleFormControlTextarea1" class="form-label">Nội dung bình luận:</label>
                    <?php endif; ?>
                    <textarea class="form-control " id="bl_noidung" rows="3" placeholder="Nhập nội dung..." style="resize: none"></textarea>
                    <p id="bl_error" class="text-danger m-0"></p>
                    <button class="btn btn-primary mt-3" type="button" id="btn-binhluan">Gửi bình luận</button>
                </div>
            </div>
        </div>
    </form>
    

    

    <section class="w-100 p-4 " style="border-radius: .5rem .5rem 0 0;" id="list-comment">
        <?php if(count($sach->count_binhluan) > 0): ?>
            <?php echo $__env->make('inc.client-list-comment', [
                'comments' => $sach->binhluan,
                'totalComment' => count($sach->count_binhluan),
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </section>
    
</div>
<?php /**PATH D:\xampp\htdocs\Laravel\library\resources\views/components/comment.blade.php ENDPATH**/ ?>