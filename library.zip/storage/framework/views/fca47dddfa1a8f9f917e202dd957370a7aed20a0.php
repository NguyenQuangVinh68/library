
<?php $__env->startSection('content'); ?>
    <?php if(session('message')): ?>
        <div class="alert alert-danger mt-5">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>

    <div class="container">
        <div class=" w-50 mx-auto form__content">
            <div class="card ">
                <div class="card-header">
                    <h4 class="card-title text-center">
                        <?php echo e(isset($user) ? 'Chỉnh sửa thông tin người dùng' : 'Thêm người dùng'); ?>

                    </h4>
                </div>
                <div class="card-content">
                    <div class="card-body">
                        <form class="form form-vertical" autocomplete="off"
                            action="<?php echo e(isset($user) ? route('user.update', $user->id) : route('user.store')); ?>"
                            method="POST">
                            <?php echo csrf_field(); ?>
                            <?php if(isset($user)): ?>
                                <?php echo method_field('PUT'); ?>
                            <?php else: ?>
                                <?php echo method_field('POST'); ?>
                            <?php endif; ?>
                            <div class="form-body">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group ">
                                            <label>Mã số</label>
                                            <input required type="text" id="ma_user"
                                                class="form-control <?php $__errorArgs = ['ma_user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ma_user"
                                                placeholder="Nhập mã số" value="<?php echo e(isset($user) ? $user->ma_user : ''); ?>">
                                            <?php $__errorArgs = ['ma_user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group ">
                                            <label>Tên</label>
                                            <input required type="text" id="ten_user"
                                                class="form-control <?php $__errorArgs = ['ten_user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ten_user"
                                                placeholder="Nhập tên" value="<?php echo e(isset($user) ? $user->ten_user : ''); ?>">
                                            <?php $__errorArgs = ['ten_user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group ">
                                            <label>Email</label>
                                            <input required type="email" id="email"
                                                class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                                                placeholder="Nhập email" value="<?php echo e(isset($user) ? $user->email : ''); ?>">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    
                                    <div class="col-12">
                                        <div class="form-group ">
                                            <label>Password</label>
                                            <input required type="password" id="password"
                                                class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                                                placeholder="Nhập password">
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    
                                    <div class="col-12">
                                        <div class="form-group ">
                                            <label>Vai trò</label>
                                            <select name="role" id="role" class="form-select">
                                                <option value="0"
                                                    <?php echo e(isset($user) ? ($user->role == 0 ? 'selected' : '') : ''); ?>>Sinh
                                                    viên</option>
                                                <option value="1"
                                                    <?php echo e(isset($user) ? ($user->role == 1 ? 'selected' : '') : ''); ?>>Admin
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-12 d-flex justify-content-end">
                                <button type="submit" class="btn btn-primary me-1 mb-1">
                                    <?php echo e(isset($user) ? 'Cập nhật' : 'Thêm'); ?>

                                </button>
                                <button type="reset" class="btn btn-light-secondary me-1 mb-1">
                                    Đặt lại
                                </button>
                            </div>
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.admin.user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\library\resources\views/pages/admin/user/form.blade.php ENDPATH**/ ?>