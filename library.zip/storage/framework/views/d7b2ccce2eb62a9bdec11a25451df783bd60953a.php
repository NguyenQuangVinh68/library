
<?php $__env->startSection('content'); ?>
    <section class="section">
        <?php if(session('message')): ?>
            <div class="alert alert-success mt-5">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>

        <?php if($kq->isNotEmpty()): ?>
            <div class="row my-5" id="table-head">
                <div class="col-12">
                    <div class="table-responsive">
                        <table class="table mb-0">
                            <thead class="thead-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>Mã số </th>
                                    <th>Tên tài khoản</th>
                                    <th>Email</th>
                                    <th>Vai trò</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $kq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($user->id); ?></td>
                                        <td><?php echo e($user->ma_user); ?></td>
                                        <td class="text-capitalize"><?php echo e($user->ten_user); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->role == 1 ? 'admin' : 'sinh viên'); ?></td>
                                        <td class="d-flex align-items-center gap-2">
                                            
                                            <button type="button"
                                                class="btn btn-outline-success block d-flex align-items-center"
                                                data-bs-toggle="modal" data-bs-target="#role<?php echo e($user->id); ?>"><i
                                                    class="bi bi-file-lock2-fill "></i></button>
                                            
                                            <a href="<?php echo e(route('user.edit', $user->id)); ?>" type="button"
                                                class="btn btn-outline-primary block d-flex align-items-center"><i
                                                    class="bi bi-pencil"></i></a>
                                            
                                            <button type="button"
                                                class="btn btn-outline-danger block d-flex align-items-center"
                                                data-bs-toggle="modal" data-bs-target="#delete<?php echo e($user->id); ?>"><i
                                                    class="bi bi-trash"></i></button>
                                        </td>
                                    </tr>

                                    
                                    <div class="modal fade" id="role<?php echo e($user->id); ?>" data-bs-backdrop="static"
                                        aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable"
                                            role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalCenterTitle">
                                                        Thay đổi vai trò
                                                    </h5>
                                                    <button type="button" class="close" data-bs-dismiss="modal"
                                                        aria-label="Close">X</button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="<?php echo e(route('user.update', $user->id)); ?>" method="POST">
                                                        <?php echo method_field('PUT'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <h4 class="text-center"> <?php echo e($user->ten_user); ?></h4>
                                                        <p class="text-center">Bạn có trắc chắn muốn thay đổi vai trò cho
                                                            "Người dùng này" ?
                                                        </p>
                                                        <input type="hidden" value="<?php echo e($user->role == 1 ? 0 : 1); ?>"
                                                            name="role" id="role">
                                                        <div class="d-flex gap-3 mt-5">
                                                            <button type="submit" class="btn btn-danger w-50">Ok,
                                                                thay đổi</button>
                                                            <button class="btn btn-secondary w-50" type="button"
                                                                data-bs-dismiss="modal" aria-label="Close">Hủy</button>
                                                        </div>
                                                    </form>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    

                                    
                                    <div class="modal fade" id="delete<?php echo e($user->id); ?>" data-bs-backdrop="static"
                                        aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable"
                                            role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalCenterTitle">
                                                        Xóa người dùng
                                                    </h5>
                                                    <button type="button" class="close" data-bs-dismiss="modal"
                                                        aria-label="Close">X</button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="<?php echo e(route('user.destroy', $user->id)); ?>" method="POST">
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <h4 class="text-center"> <?php echo e($user->ten_user); ?></h4>
                                                        <p class="text-center">Bạn có trắc chắn muốn xóa "Người Dùng" này?
                                                        </p>
                                                        <div class="d-flex gap-3 mt-5">
                                                            <button type="submit" class="btn btn-danger w-50">Ok,
                                                                xóa</button>
                                                            <button class="btn btn-secondary w-50" type="button"
                                                                data-bs-dismiss="modal" aria-label="Close">Hủy</button>
                                                        </div>
                                                    </form>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            
            <?php echo e($kq->links('inc.pagination')); ?>

            
        <?php else: ?>
            <div class="text-center">
                <h3 class="alert-danger  p-3">Không thấy dữ liệu</h3>
                <a href="<?php echo e(URL::previous()); ?> " class="btn btn-secondary mx-auto">Trở lại</a>
            </div>
        <?php endif; ?>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.admin.user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\library\resources\views/pages/admin/user/index.blade.php ENDPATH**/ ?>