
<?php $__env->startSection('main'); ?>
    <div class="row my-5 ">
        <div class="col-md-6 mb-1">
            <h4 class="text-capitalize text-decoration-none fs-2 d-block fw-bold ">Nhật ký</h4>
        </div>
    </div>

    <?php echo $__env->yieldContent('content'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\library\resources\views/pages/admin/nhatky/layout.blade.php ENDPATH**/ ?>