
<?php $__env->startSection('content'); ?>
    <?php if(session('message')): ?>
        <div class="alert alert-danger mt-5">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
    <?php
    
    ?>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title text-center"><?php echo e(isset($sach) ? 'Chỉnh sửa sách' : 'Thêm sách'); ?></h4>
            </div>
            <div class="card-content">
                <div class="card-body">
                    <form class="form form-vertical" autocomplete="off"
                        action="<?php echo e(isset($sach) ? route('sach.update', $sach->id) : route('sach.store')); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($sach)): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php else: ?>
                            <?php echo method_field('POST'); ?>
                        <?php endif; ?>
                        <div class="form-body">
                            <div class="row">
                                <div class="col-md-6 col-12">
                                    <div class="form-group ">
                                        <label>Nhan đề</label>
                                        <input type="text" id="nhande" class="form-control" name="nhande"
                                            placeholder="Nhập nhan đề" value="<?php echo e(isset($sach) ? $sach->nhande : ''); ?>">
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        <label>Tác giả</label>
                                        <input type="text" id="tacgia" class="form-control" name="tacgia"
                                            placeholder="Nhập tác giả" value="<?php echo e(isset($sach) ? $sach->tacgia : ''); ?>">
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        <label>Danh mục</label>
                                        <fieldset class="form-group">
                                            <select name="danhmuc" id="danhmuc" class="form-select">
                                                <?php $__currentLoopData = $danhmucs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $danhmuc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($danhmuc->tendm); ?>"
                                                        <?php echo e(isset($sach) ? ($sach->danhmuc == $danhmuc->tendm ? 'selected' : '') : ''); ?>>
                                                        <?php echo e($danhmuc->tendm); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </fieldset>
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        <label>Ảnh bìa</label>
                                        <input type="file" id="anhbia" class="form-control" name="anhbia"
                                            <?php echo e(isset($sach) ? '' : ''); ?>>
                                        <?php if(isset($sach)): ?>
                                            <img src="<?php echo e(asset('assets/images/books/' . $sach->anhbia)); ?>" alt=""
                                                style="width:10%">
                                        <?php endif; ?>
                                        <?php echo $errors->first('anhbia', '<span class="text-danger">:message</span>'); ?>

                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        <label>Ngành</label>
                                        <select name="nganh" id="nganh" class="form-select">
                                            <?php $__currentLoopData = $nganhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nganh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($nganh->id); ?>"
                                                    <?php echo e(isset($sach) ? ($sach->nganh == $nganh->tennganh ? 'selected' : '') : ''); ?>>
                                                    <?php echo e($nganh->tennganh); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        <label>Sách online</label>
                                        <input type="file" id="file_pdf" class="form-control" name="file_pdf"
                                            <?php echo e(isset($sach) ? '' : ''); ?>>
                                        <?php if(isset($sach)): ?>
                                            <p><?php echo e($sach->file_pdf); ?></p>
                                        <?php endif; ?>
                                        <?php echo $errors->first('file_pdf', '<span class="text-danger">:message</span>'); ?>

                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        <label>Thông tin xuất bản</label>
                                        <input type="text" id="thongtinxb" class="form-control" name="thongtinxb"
                                            placeholder="Nhập thông tin xuất bản"
                                            value="<?php echo e(isset($sach) ? $sach->thongtinxb : ''); ?>">
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        <label>Vị trí</label>
                                        <select name="vitri" id="vitri" class="form-select">
                                            <?php $__currentLoopData = $vitris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vitri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($vitri->tenvitri); ?>"
                                                    <?php echo e(isset($sach) ? ($sach->vitri == $vitri->tenvitri ? 'selected' : '') : ''); ?>>
                                                    <?php echo e($vitri->tenvitri); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        <label>Số lượng</label>
                                        <input type="text" id="soluong" class="form-control" name="soluong"
                                            placeholder="Nhập số lượng" value="<?php echo e(isset($sach) ? $sach->soluong : ''); ?>">
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        <label>Giá</label>
                                        <input type="text" id="gia" class="form-control" name="gia"
                                            placeholder="Nhập giá sách" value="<?php echo e(isset($sach) ? $sach->gia : ''); ?>">
                                    </div>
                                </div>
                                
                                <div class="col-12 d-flex justify-content-end">
                                    <button type="submit" class="btn btn-primary me-1 mb-1">
                                        <?php echo e(isset($sach) ? 'Cập nhật' : 'Thêm'); ?>

                                    </button>
                                    <button type="reset" class="btn btn-light-secondary me-1 mb-1">
                                        Đặt lại
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.admin.sach.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\library\resources\views/pages/admin/sach/form.blade.php ENDPATH**/ ?>