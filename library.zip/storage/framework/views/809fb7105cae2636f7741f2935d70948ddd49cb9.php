
<?php $__env->startSection('main'); ?>
    <div class="row my-3 ">
        <div class="col-md-6 mb-1">
            <h1 class="text-capitalize fs-3 fw-bold" href="#">Hoạt động</h1>
        </div>
    </div>

    <?php echo $__env->yieldContent('content'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\library\resources\views/pages/admin/muonsach/layout.blade.php ENDPATH**/ ?>