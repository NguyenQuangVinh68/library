<?php
    use Illuminate\Support\Carbon;
    Carbon::setLocale('vi');
?>
<div class="row d-flex justify-content-center">
    <div class="col-md-12 col-lg-10 col-xl-8">
        <div class="card">
            <div class="card-body p-4">
                <h4 class="text-center mb-4 pb-2">Các bình luận (<?php echo e($totalComment); ?>)</h4>
                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $binhluan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="col">
                            <div class="d-flex flex-start mt-4 pb-3 border-bottom">
                                <img class="rounded-circle shadow-1-strong me-3"
                                    src="<?php echo e(asset('assets/images/faces/2.jpg')); ?>" alt="avatar" width="40"
                                    height="40">
                                <div class="flex-grow-1 flex-shrink-1">
                                    <div>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <h6 class="mb-1"><?php echo e($binhluan->user->ten_user); ?>&emsp;<span
                                                    class="small text-secondary">
                                                    <?php echo e(Carbon::parse($binhluan->created_at)->diffForHumans()); ?></span>
                                            </h6>
                                        </div>
                                        <p class="small mb-0"><?php echo e($binhluan->bl_noidung); ?></p>

                                        
                                        <?php if(Auth::id()): ?>
                                            <a href="" data-id_comment="<?php echo e($binhluan->id); ?>"
                                                class="btn-show-form-reply"><i class="bi bi-reply-fill"></i></i><span
                                                    class="small">trả
                                                    lời</span></a>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('login')); ?>"><span class="small">đăng
                                                    nhập để trả lời</span></a>
                                        <?php endif; ?>
                                        
                                        
                                        <div class="card formReply form-reply-<?php echo e($binhluan->id); ?>" style="display:none">
                                            <div class="card-body ps-0">
                                                <div class="form-group mb-3">
                                                    <label for="exampleFormControlTextarea1" class="form-label">Nội
                                                        dung bình luận:</label>
                                                    <textarea class="form-control" id="tl_noidung<?php echo e($binhluan->id); ?>" rows="3" placeholder="Nhập nội dung..."
                                                        style="resize: none" name="bl_noidung"></textarea>
                                                    <p id="bl_error" class="text-danger m-0"></p>
                                                    <button type="button" data-id_comment="<?php echo e($binhluan->id); ?>"
                                                        class="btn btn-primary mt-3 btn-send-comment-reply"
                                                        type="button">Gửi bình
                                                        luận</button>
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>

                                    
                                    <?php $__currentLoopData = $binhluan->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="d-flex flex-start mt-4">
                                            <a class="me-3" href="#">
                                                <img class="rounded-circle shadow-1-strong"
                                                    src="<?php echo e(asset('assets/images/faces/1.jpg')); ?>" alt="avatar"
                                                    width="40" height="40">
                                            </a>
                                            <div class="flex-grow-1 flex-shrink-1">
                                                <div>
                                                    <div class="d-flex justify-content-between align-items-center">
                                                        <h6 class="mb-1"><?php echo e($reply->user->ten_user); ?>&emsp;<span
                                                                class="small text-secondary">
                                                                <?php echo e(Carbon::parse($reply->created_at)->diffForHumans()); ?></span>
                                                        </h6>
                                                    </div>
                                                    <p class="small mb-0"><?php echo e($reply->bl_noidung); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\Laravel\library\resources\views/inc/client-list-comment.blade.php ENDPATH**/ ?>