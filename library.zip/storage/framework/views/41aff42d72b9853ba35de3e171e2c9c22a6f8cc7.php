<?php if(count($kq) > 0): ?>
    <div class="col-12">
        <div class="table-responsive">
            <table class="table mb-0">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th>
                        <th>Nhan đề</th>
                        <th>Tác giả</th>
                        <th>Danh mục</th>
                        <th>Khoa</th>
                        <th>Ngành</th>
                        <th>Ảnh bìa</th>
                        <th>Thông tin xb</th>
                        <th>Vị trí</th>
                        <th>Số lượng</th>
                        <th>Giá</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $kq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($sach->id); ?></td>
                            <td><?php echo e($sach->nhande); ?></td>
                            <td class="text-capitalize"><?php echo e($sach->tacgia); ?></td>
                            <td><?php echo e($sach->danhmuc); ?></td>
                            <td>
                                <?php echo e($sach->khoa == 'công nghệ thông tin - điện tử' ? 'CNTT-DT' : $sach->khoa); ?>

                            </td>
                            <td><?php echo e($sach->nganh); ?></td>
                            <td><img src="<?php echo e(asset('assets/images/books/' . $sach->anhbia)); ?>" alt=""
                                    class="w-50"></td>
                            <td><?php echo e($sach->thongtinxb); ?></td>
                            <td><?php echo e($sach->vitri); ?></td>
                            <td><?php echo e($sach->soluong); ?></td>
                            <td><?php echo e($sach->gia); ?></td>
                            <td>
                                <a href="<?php echo e(route('sach.edit', $sach->id)); ?>" type="button"
                                    class="btn btn-outline-primary block "><i class="bi bi-pencil"></i></a>
                                <button type="button" class="btn btn-outline-danger block " data-bs-toggle="modal"
                                    data-bs-target="#modal<?php echo e($sach->id); ?>"><i class="bi bi-trash"></i></button>
                            </td>
                        </tr>

                        <div class="modal fade" id="modal<?php echo e($sach->id); ?>" data-bs-backdrop="static"
                            aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable"
                                role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalCenterTitle">
                                            Xóa ngành
                                        </h5>
                                        <button type="button" class="close" data-bs-dismiss="modal"
                                            aria-label="Close">X</button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('sach.destroy', $sach->id)); ?>" method="POST">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <h4 class="text-center"> <?php echo e($sach->nhande); ?></h4>
                                            <p class="text-center">Bạn có trắc chắn muốn xóa "NGÀNH" này?</p>
                                            <div class="d-flex gap-3 mt-5">
                                                <button type="submit" class="btn btn-danger w-50">Ok,
                                                    xóa</button>
                                                <button class="btn btn-secondary w-50" type="button"
                                                    data-bs-dismiss="modal" aria-label="Close">Hủy</button>
                                            </div>
                                        </form>

                                    </div>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php else: ?>
    <h3 class="p-3 text-center alert-danger">Không có dữ liệu</h3>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\Laravel\library\resources\views/inc/admin-list-sach.blade.php ENDPATH**/ ?>