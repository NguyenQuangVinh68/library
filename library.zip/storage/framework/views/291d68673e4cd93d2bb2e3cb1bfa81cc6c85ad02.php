
<?php $__env->startSection('content'); ?>
    <section class="section">
        <?php if(session('message')): ?>
            <div class="alert alert-success mt-5">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
        <?php if(isset($message_404)): ?>
            <div class=" mt-5 text-center">
                <p class="fs-3 fw-bold  alert alert-danger"><?php echo e($message_404); ?></p>
                <a href="<?php echo e(route('sach.index')); ?>" class="btn btn-light-secondary w-25 ">Trở lại</a>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="form-group">
                    <?php
                        $khoas = App\Models\Khoa::all();
                        $nganhs = App\Models\Nganh::all();
                    ?>
                    <label for="" class="form-label">Kiểm tra số lượng sách theo Khoa/Ngành</label>
                    <select name="nganh_khoa" id="nganh_khoa" class="form-select">
                        <?php $__currentLoopData = $khoas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $khoa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($khoa->tenkhoa); ?>">Khoa <?php echo e($khoa->tenkhoa); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $nganhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nganh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($nganh->tennganh); ?>">Ngành <?php echo e($nganh->tennganh); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>

        <div class="row my-5" id="view-book">
            <?php if(isset($kq)): ?>
                <div class="col-12">
                    <div class="table-responsive">
                        <table class="table mb-0">
                            <thead class="thead-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>Nhan đề</th>
                                    <th>Tác giả</th>
                                    <th>Danh mục</th>
                                    <th>Khoa</th>
                                    <th>Ngành</th>
                                    <th>Ảnh bìa</th>
                                    <th>Thông tin xb</th>
                                    <th>Vị trí</th>
                                    <th>Số lượng</th>
                                    <th>Giá</th>
                                    <th>PDF</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $kq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($sach->id); ?></td>
                                        <td><?php echo e($sach->nhande); ?></td>
                                        <td class="text-capitalize"><?php echo e($sach->tacgia); ?></td>
                                        <td><?php echo e($sach->danhmuc); ?></td>
                                        <td>
                                            <?php echo e($sach->khoa == 'công nghệ thông tin - điện tử' ? 'CNTT-DT' : $sach->khoa); ?>

                                        </td>
                                        <td><?php echo e($sach->nganh); ?></td>
                                        <td><img src="<?php echo e(asset('assets/images/books/' . $sach->anhbia)); ?>" alt=""
                                                class="w-50"></td>
                                        <td><?php echo e($sach->thongtinxb); ?></td>
                                        <td><?php echo e($sach->vitri); ?></td>
                                        <td><?php echo e($sach->soluong); ?></td>
                                        <td><?php echo e($sach->gia); ?></td>
                                        <?php if($sach->file_pdf != null): ?>
                                            <td><a href="<?php echo e(asset('assets/tailieu/' . $sach->file_pdf)); ?>" target="_blank"
                                                    alt="File pdf" class="nav-link">xem file</a></td>
                                        <?php else: ?>
                                            <td>không file</td>
                                        <?php endif; ?>
                                        <td>
                                            <a href="<?php echo e(route('sach.edit', $sach->id)); ?>" type="button"
                                                class="btn btn-outline-primary block "><i class="bi bi-pencil"></i></a>
                                            <button type="button" class="btn btn-outline-danger block "
                                                data-bs-toggle="modal" data-bs-target="#modal<?php echo e($sach->id); ?>"><i
                                                    class="bi bi-trash"></i></button>
                                        </td>
                                    </tr>

                                    <div class="modal fade" id="modal<?php echo e($sach->id); ?>" data-bs-backdrop="static"
                                        aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable"
                                            role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalCenterTitle">
                                                        Xóa ngành
                                                    </h5>
                                                    <button type="button" class="close" data-bs-dismiss="modal"
                                                        aria-label="Close">X</button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="<?php echo e(route('sach.destroy', $sach->id)); ?>" method="POST">
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <h4 class="text-center"> <?php echo e($sach->nhande); ?></h4>
                                                        <p class="text-center">Bạn có trắc chắn muốn xóa "NGÀNH" này?</p>
                                                        <div class="d-flex gap-3 mt-5">
                                                            <button type="submit" class="btn btn-danger w-50">Ok,
                                                                xóa</button>
                                                            <button class="btn btn-secondary w-50" type="button"
                                                                data-bs-dismiss="modal" aria-label="Close">Hủy</button>
                                                        </div>
                                                    </form>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <?php echo e($kq->links('inc.pagination')); ?>

                
            <?php endif; ?>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('ajax'); ?>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
        })
        $(document).ready(function() {
            $('#nganh_khoa').change(function(ev) {
                ev.preventDefault();
                var value_khoa_nganh = $('#nganh_khoa').val();
                var fillterURL = '<?php echo e(route('sach.loc')); ?>';

                $.ajax({
                    url: fillterURL,
                    method: "POST",
                    data: {
                        'khoa_nganh': value_khoa_nganh,
                    },
                    success: function(res) {
                        $('#view-book').html(res);
                        // console.log(res);
                    }
                })
            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('pages.admin.sach.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\library\resources\views/pages/admin/sach/index.blade.php ENDPATH**/ ?>