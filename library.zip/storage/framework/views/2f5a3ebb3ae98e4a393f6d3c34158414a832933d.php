
<?php $__env->startSection('content'); ?>
    <div class="container w-50 mx-auto">
        <div class="card">
            <div class="card-header">
                <h3 class="text-center">Thêm số ngày gia hạn</h3>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('giahan.post')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="" class="form-label">Số ngày gia hạn</label>
                        <input type="hidden" name="mamuon" value="<?php echo e($id); ?>">
                        <input type="text" class="form-control <?php $__errorArgs = ['songay_giahan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="songay_giahan" placeholder="Nhập số ngày cần gia hạn">
                        <?php $__errorArgs = ['songay_giahan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <button type="submit" class="btn btn-primary mt-2">Gia hạn</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.admin.muonsach.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\library\resources\views/pages/admin/trasach/form_giahan.blade.php ENDPATH**/ ?>