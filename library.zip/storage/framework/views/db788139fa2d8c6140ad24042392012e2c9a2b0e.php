
<?php $__env->startSection('content'); ?>
    <section class="section">
        <?php if(session('message')): ?>
            <div class="alert alert-success mt-5">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
        <?php if(isset($message_404)): ?>
            <div class=" mt-5 text-center">
                <p class="fs-3 fw-bold  alert alert-danger"><?php echo e($message_404); ?></p>
                <a href="<?php echo e(route('khoa.index')); ?>" class="btn btn-light-secondary w-25 ">Trở lại</a>
            </div>
        <?php endif; ?>

        <div class="row" id="table-head">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title text-center">Nhật kí thư viện </h5>
                    </div>
                    <div class="card-body">
                        <ul class="nav nav-tabs" id="myTab">

                            <?php
                                $tabData = ['Ngày', 'Tháng', 'Năm'];
                            ?>
                            <?php for($i = 0; $i < count($tabData); $i++): ?>
                                <form action="">
                                    <?php echo csrf_field(); ?>
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link tab_nhatky" data-bs-toggle="tab"
                                            data-nhatky_id="<?php echo e($b = $i + 1); ?>"
                                            href="#nhatky<?php echo e($a = $i + 1); ?>"><?php echo e($tabData[$i]); ?></a>
                                    </li>
                                </form>
                            <?php endfor; ?>

                            
                            <li class="nav-item" role="presentation">
                                <a class="nav-link tab_nhatky" data-bs-toggle="tab" href="#tab_tuychinh">Tùy chỉnh</a>
                            </li>

                        </ul>
                        <div class="tab-content mt-4">
                            <?php for($i = 0; $i < count($tabData); $i++): ?>
                                <div class="tab-pane<?php echo e($b = $i + 1); ?> fade fade_display" id="nhatky<?php echo e($a = $i + 1); ?>">
                                </div>
                            <?php endfor; ?>

                            
                            <div class="tab-pane fade fade_display mt-5" id="tab_tuychinh">
                                <form action="">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Từ ngày</label>
                                                <input type="date" class="form-control" name="tuNgay" id="tuNgay">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Đến ngày</label>
                                                <input type="date" class="form-control" name="denNgay" id="denNgay">
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <button class="btn btn-primary" type="button" id="actionChoose">Thực
                                                hiện</button>
                                        </div>
                                    </div>
                                </form>
                                
                                <div id="viewTuyChon" class="mt-5"></div>
                                
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <?php if(isset($kq)): ?>
        <?php echo e($kq->links('inc.pagination')); ?>

    <?php endif; ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.admin.nhatky.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\library\resources\views/pages/admin/nhatky/index.blade.php ENDPATH**/ ?>