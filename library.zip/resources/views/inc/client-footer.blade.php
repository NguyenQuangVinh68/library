<footer class="py-5 bg-footer">
    <div class="container-fluid p-0">
        <div class="text-center text-white">
            <p class="mb-0 text-capitalize">thư viện cao đẳng công nghệ thông tin tp.HCM - ITC</p>
            <p class="mb-0"><a href="" class="text-white">info@itc.edu.vn</a></p>
            <p class="mb-0">© Copyright by MyTeam</p>
        </div>
    </div>
    <div class="container-fluid text-center background-footer overflow-hidden">
        <img class="w-100 background1"
            src="https://vn.got-it.ai/blog/wp-content/themes/gotitblog/assets/images/footer-top.svg" alt="">
    </div>
</footer>

<style>
    body.theme-dark .bg-footer {
        background: linear-gradient(99deg, rgb(25 25 28 / 81%) 0%, rgb(8 16 30 / 90%) 100%);
        border-top: 1px solid #fff;
    }

    .bg-footer {
        background: linear-gradient(99deg, rgb(43 69 160) 0%, rgb(16 67 159) 100%);
    }
</style>
