@extends('layouts.admin')
@section('main')
    <div class="row my-3 ">
        <div class="col-md-6 mb-1">
            <h1 class="text-capitalize fs-3 fw-bold" href="#">Hoạt động</h1>
        </div>
    </div>

    @yield('content')
@endsection
